# Source-checking skill

Portable Kosh package · draft

This is an unsaved local snapshot, not a server revision.
Content SHA-256: 2d95f298b12c43057f9feb0fb0bbea76e83828f991c94b1cb680773350e5e4fd

## Use
Read skill.md and governance.md. Supply the declared inputs in a destination you trust. Review the output yourself. No host integration or installation has been tested.

## Limits
Governance rules are instructions only, not runtime enforcement. Structural and credential-pattern checks cannot establish factual accuracy, safety or the absence of secrets. No scripts or connectors are included.

## Source
Kramaniti Kosh: source-checking-skill, version 1.1.

Sample input and output are excluded.
