# Mobile review 320

Portable Kosh package · human-reviewed

This is an unsaved local snapshot, not a server revision.
Content SHA-256: 1f566b61ecf4e008e582c232cadc517867970062ebf0d4b0822b41cf3db27a2a

## Use
Read skill.md and governance.md. Supply the declared inputs in a destination you trust. Review the output yourself. No host integration or installation has been tested.

## Limits
Governance rules are instructions only, not runtime enforcement. Structural and credential-pattern checks cannot establish factual accuracy, safety or the absence of secrets. No scripts or connectors are included.

Sample input and output are excluded.
