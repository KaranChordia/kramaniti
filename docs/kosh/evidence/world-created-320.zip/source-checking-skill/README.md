# Source-checking skill

Portable Kosh package · draft

This is an unsaved local snapshot, not a server revision.
Content SHA-256: 043db3f729a2df10aa9326331be28fff3ace244c58bdbb775a4cb00e9eff5608

## Use
Read skill.md and governance.md. Supply the declared inputs in a destination you trust. Review the output yourself. No host integration or installation has been tested.

## Limits
Governance rules are instructions only, not runtime enforcement. Structural and credential-pattern checks cannot establish factual accuracy, safety or the absence of secrets. No scripts or connectors are included.

## Source
Kramaniti Kosh: source-checking-skill, version 1.1.

Sample input and output are excluded.
