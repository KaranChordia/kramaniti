# Boundaries

Status: Instruction only. Kosh has no tool executor. The destination must enforce permissions and approval gates.

## Allowed sources
Use only the information supplied for this task.

## Permitted actions
Read supplied context and prepare a draft for human review.

## Prohibited actions
Do not call external tools, run code, send messages or invent evidence.

## Human approval required
A human must approve consequential external actions in the destination runtime.

## Missing information
Stop and ask when required information is missing. Mark uncertainty explicitly.

## Escalation owner
Unresolved
