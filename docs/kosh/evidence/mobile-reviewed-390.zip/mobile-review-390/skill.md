# Mobile review 390

## Purpose
Turn supplied notes into a reviewable brief.

## Use when
A decision needs supplied evidence.

## Inputs
- Notes (text, required): Supply notes and the decision question.

## Method
1. Read the notes, identify evidence and missing information.

## Output
A brief with sources and unanswered questions.

## Quality checks
Every fact comes from supplied notes.

## Limitations
Cannot independently verify sources.
