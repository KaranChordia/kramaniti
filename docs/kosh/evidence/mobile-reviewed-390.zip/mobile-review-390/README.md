# Mobile review 390

Portable Kosh package · human-reviewed

This is an unsaved local snapshot, not a server revision.
Content SHA-256: e4164904cb977050e405f8636b1298d48edc1732c69ea71162950a7533aad5aa

## Use
Read skill.md and governance.md. Supply the declared inputs in a destination you trust. Review the output yourself. No host integration or installation has been tested.

## Limits
Governance rules are instructions only, not runtime enforcement. Structural and credential-pattern checks cannot establish factual accuracy, safety or the absence of secrets. No scripts or connectors are included.

Sample input and output are excluded.
