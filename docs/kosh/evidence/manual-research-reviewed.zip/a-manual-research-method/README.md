# A manual research method

Portable Kosh package · human-reviewed

This is an unsaved local snapshot, not a server revision.
Content SHA-256: 97aed22f1f1ad85a776ec8e5e0b1070baa39f5a4bb6d8543847688881575e178

## Use
Read skill.md and governance.md. Supply the declared inputs in a destination you trust. Review the output yourself. No host integration or installation has been tested.

## Limits
Governance rules are instructions only, not runtime enforcement. Structural and credential-pattern checks cannot establish factual accuracy, safety or the absence of secrets. No scripts or connectors are included.

Sample input and output are excluded.
