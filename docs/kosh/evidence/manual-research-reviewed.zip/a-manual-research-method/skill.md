# A manual research method

## Purpose
Turn supplied research into an evidence-backed brief for a decision.

## Use when
A decision needs supplied evidence.

## Inputs
- Sources (text, required): Provide labelled source excerpts.

## Method
1. Read the sources and identify the decision.
2. Draft the brief with evidence and unresolved questions.

## Output
A concise decision brief.

## Quality checks
Every claim has a source.

## Limitations
Cannot independently verify facts.
